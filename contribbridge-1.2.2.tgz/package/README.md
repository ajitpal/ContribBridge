

# 🌎 ContribBridge

![ContribBridge Hero Visual](hero_demo_visual_1773611334570.png)

**Translate every GitHub issue in real-time using the Lingo.dev SDK — bidirectionally, across 87 languages, with zero config.**

[**Live Dashboard Demo**](https://contibbridge-production.up.railway.app/dashboard/) | [**GitHub Repo**](https://github.com/ajitpal/ContribBridge)

57% of the world's developers don't write English fluently. They file bugs, find security issues, and request features — but maintainers never see them because they aren't written in English. **ContribBridge** fixes this with three simple command.

---

## 📐 Architecture

```mermaid
graph TD
    GH[GitHub Repository] -- "Webhook Event" --> WB[Express Server: /webhook/github]
    
    subgraph "Verification & Gating"
        WB --> SIG[HMAC-SHA256 Signature Verify]
        SIG -- "ACK 200" --> GH
        SIG --> GATE[License Validation]
    end
    
    subgraph "Translation Pipeline (Powered by Lingo.dev)"
        GATE --> DET[Language Detection]
        DET --> TRA[Issue/Comment Translation]
        TRA --> ENR[AI Enrichment: Labels & Severity]
    end
    
    subgraph "Output & Persistence"
        ENR --> POST[Post-back to GitHub via Octokit]
        ENR --> BCAST[WebSocket Broadcast to Dashboard]
        ENR --> DB[(SQLite Persistence)]
    end
    
    POST --> GH
    BCAST --> UI[Live Dashboard UI]
```

## 📂 Project Structure

```text
contribbridge/
├── bin/
│   └── cli.js          # CLI entry point (init, connect, watch)
├── src/
│   ├── server.js       # Express app & GitHub Webhook endpoint
│   ├── pipeline.js     # Main orchestrator for translation flow
│   ├── translate.js    # Lingo.dev SDK wrapper
│   ├── detect.js       # Language detection utility
│   ├── enrich.js       # AI label & severity extraction
│   ├── github.js       # Octokit integration (Post-back & Webhooks)
│   ├── dashboard.js    # WebSocket server for live feed
│   ├── cache.js        # node-cache for deduplication
│   ├── db.js           # SQLite setup (Issues & Licenses)
│   └── middleware/
│       ├── licenseGate.js  # License validation logic
│       └── verifyGhSig.js  # GitHub HMAC verification
├── dashboard/
│   └── index.html      # Real-time dashboard frontend
├── keys/               # RS256 Keypair for offline licensing
└── .env.example        # Environment template
```
## 🚀 Quick Start (Production)

If you are deploying to a server (e.g., Railway, Heroku, AWS):

```bash
# 1. Install & Initialize
npx contribbridge init  # Prompts for API Keys & sets up .env

# 2. Connect your Repository
npx contribbridge connect --repo your-org/your-repo

# 3. Start Watching
npx contribbridge watch  # Starts the translation server + dashboard
```

## 🚀 Local Development & Testing

ContribBridge is designed to be "catered" for local use. No need to install third-party tunnel tools manually.

### 1. Prerequisites
- **Lingo.dev API Key**: Get one at [lingo.dev/dashboard](https://lingo.dev/dashboard).
- **GitHub PAT (Fine-grained)**: [Create one](https://github.com/settings/tokens?type=beta) with `Issues` (R/W), `Webhooks` (W), and `Metadata` (R).
- **Node.js**: v20 or higher.

### 2. The "Catered" Setup
Initialize the environment and connect your repository in one flow:

```bash
# 1. Start the wizard
npx contribbridge init
# ➜ Select "y" when asked about Smee.io to automate tunneling!

# 2. Connect a test repository
npx contribbridge connect --repo your-username/test-repo

# 3. Start the Engine
npx contribbridge watch
# ➜ This automatically starts both the Express server AND the Smee tunnel.
```

- **Dashboard**: Open `http://localhost:4000/dashboard` in your browser.
- **Webhook**: Automatically active via your unique Smee URL!

### 3. Run a Test
Go to your GitHub test repository and create a **New Issue** in a non-English language:

- **Title**: `¡Hola! El sistema no funciona`
- **Body**: `He intentado registrarme pero el botón de envío no responde en dispositivos móviles.`

**The Magic:** Within seconds, you'll see the translated issue appear on your dashboard, and a translated comment will be posted back to GitHub with suggested labels!

---

## ✨ Features

- **87 Languages Supported**: Powered by the high-fidelity [Lingo.dev SDK](https://lingo.dev).
- **Zero Config**: Automagically detects language and translates to English (or your target locale).
- **Bidirectional**: Maintainers reply in English; ContribBridge translates it back for the contributor.
- **Code Preservation**: Intelligent markdown and code block preservation during translation.
- **Live Dashboard**: Watch translations happen in real-time via a clean WebSocket-powered feed.
- **Universal Support**: Built to work with any repository setup.

---

## 🛠️ Tech Stack

| Layer | Technology |
| --- | --- |
| **Translation** | Lingo.dev SDK (detectLocale, localizeText, localizeHtml, localizeChat) |
| **Runtime** | Node.js 20 LTS (ESM) |
| **Framework** | Express.js 4.18 |
| **GitHub API** | @octokit/rest (Octokit) |
| **Real-time** | WebSocket (ws v8) |
| **Database** | SQLite via better-sqlite3 |
| **Authentication** | RS256 JWT (License Verification) |


---

## 📄 License

License: **Apache 2.0**

---

*Built with ❤️ for the Lingo.dev Hackathon.*
